package com.rekalcula.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
